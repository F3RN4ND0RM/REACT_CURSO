export const msg1 = (req, res) => res.send("Hola Mundo!");
export const msg2 = (req, res) => res.send("Polo!");
export const msg3 = (req, res) => res.send("Ping!");
export const msg4 = (req, res) => res.send("ABC!");
